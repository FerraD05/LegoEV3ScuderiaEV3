package testEv3Simulation;

import javax.swing.*;
import java.awt.*;

public class EV3Simulation extends JPanel {
	private static final long serialVersionUID = 1L;
	private static final double WHEEL_DISTANCE = 50;
    private static final double WHEEL_RADIUS = 10;
    public double leftWheelSpeed = 0; // degrees per second
    public double rightWheelSpeed = 0; // degrees per second
    public static final double ACCELERATION = 10;
    public static final double MAX_LEFT_WHEEL_SPEED = 200;
    public static final double MAX_RIGHT_WHEEL_SPEED = 200;
    public static final double FRICTION = 5; // Friction deceleration rate
    
    private double x = 300;
    private double y = 300;
    private double angle = 0; // radians
    
    public EV3Simulation() {
        setFocusable(true);
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(600, 600));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Calculate the positions of the wheels
        double leftWheelX = x - (WHEEL_DISTANCE / 2) * Math.sin(angle);
        double leftWheelY = y + (WHEEL_DISTANCE / 2) * Math.cos(angle);
        double rightWheelX = x + (WHEEL_DISTANCE / 2) * Math.sin(angle);
        double rightWheelY = y - (WHEEL_DISTANCE / 2) * Math.cos(angle);

        // Calculate the position of the front dot
        double frontX = x + 30 * Math.cos(angle);
        double frontY = y + 30 * Math.sin(angle);

        // Draw the rod
        g2d.drawLine((int) leftWheelX, (int) leftWheelY, (int) rightWheelX, (int) rightWheelY);

        // Draw the wheels
        g2d.fillOval((int) (leftWheelX - WHEEL_RADIUS), (int) (leftWheelY - WHEEL_RADIUS), (int) (2 * WHEEL_RADIUS), (int) (2 * WHEEL_RADIUS));
        g2d.fillOval((int) (rightWheelX - WHEEL_RADIUS), (int) (rightWheelY - WHEEL_RADIUS), (int) (2 * WHEEL_RADIUS), (int) (2 * WHEEL_RADIUS));

        // Draw the front dot
        g2d.fillOval((int) (frontX - 2), (int) (frontY - 2), 4, 4);
    }

    
    
    public void update() {
        // Calculate the distance each wheel has traveled
        double leftDistance = leftWheelSpeed * 0.016; // assuming 60 FPS
        double rightDistance = rightWheelSpeed * 0.016;

        // Calculate the change in angle
        double dAngle = (rightDistance - leftDistance) / WHEEL_DISTANCE;

        // Calculate the new angle
        angle += dAngle;

        // Calculate the change in position
        double distance = (leftDistance + rightDistance) / 2;
        x += distance * Math.cos(angle);
        y += distance * Math.sin(angle);

        repaint();
    }
    
}
