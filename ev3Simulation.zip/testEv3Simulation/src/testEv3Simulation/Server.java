package testEv3Simulation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JFrame;

public class Server {
    static EV3Simulation simulation = new EV3Simulation();

    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    private Thread listenerThread;
    private volatile boolean running = true;

    public static final String SQUARE = "0";
    public static final String X = "1";
    public static final String O = "2";
    public static final String TRIANGLE = "3";
    public static final String L1 = "4";
    public static final String R1 = "5";
    public static final String ARROWS = "pov";
    public static final String SHARE = "8";
    public static final String OPTION = "9";
    public static final String LSTICKBTN = "10";
    public static final String RSTICKBTN = "11";
    public static final String PSBTN = "12";
    public static final String TOUCHPADBTN = "13";
    public static final String RSTICKXAXIS = "z";
    public static final String RSTICKYAXIS = "rz";
    public static final String LSTICKXAXIS = "x";
    public static final String LSTICKYAXIS = "y";
    public static final String R2 = "ry";
    public static final String L2 = "rx";

    private boolean sinistraPressed = false;
    private boolean destraPressed = false;
    private boolean suPressed = false;
    private boolean giuPressed = false;
    private boolean avantiPressed = false;
    private boolean indietroPressed = false;

    // Variables to store input values
    private float lstickXValue = 0;
    private float rstickYValue = 0;
    private float r2Value = 0;
    private float l2Value = 0;

    public Server() {
        super();
    }

    
    public void updateLoop() {
        long lastTime = System.nanoTime();
        final double targetFPS = 60.0;
        final double nsPerFrame = 1000000000.0 / targetFPS;
        double delta = 0;

        while (true) {
            long now = System.nanoTime();
            delta += (now - lastTime) / nsPerFrame;
            lastTime = now;

            // Update the simulation if enough time has passed for one frame
            while (delta >= 1) {
                // Update the simulation's wheel speeds
                if (avantiPressed) {
                    simulation.leftWheelSpeed += r2Value * simulation.MAX_LEFT_WHEEL_SPEED;
                    simulation.rightWheelSpeed += r2Value * simulation.MAX_RIGHT_WHEEL_SPEED;
                }
                if (indietroPressed) {
                    simulation.leftWheelSpeed -= l2Value * simulation.MAX_LEFT_WHEEL_SPEED;
                    simulation.rightWheelSpeed -= l2Value * simulation.MAX_RIGHT_WHEEL_SPEED;
                }
                // Turning logic
                if (destraPressed) {
                    simulation.rightWheelSpeed += Math.abs(lstickXValue) * simulation.rightWheelSpeed;
                    simulation.leftWheelSpeed -= Math.abs(lstickXValue) * simulation.leftWheelSpeed;
                }
                if (sinistraPressed) {
                    simulation.rightWheelSpeed -= Math.abs(lstickXValue) * simulation.rightWheelSpeed;
                    simulation.leftWheelSpeed += Math.abs(lstickXValue) * simulation.leftWheelSpeed;
                }

                // Apply speed limits
                simulation.leftWheelSpeed = Math.max(-simulation.MAX_LEFT_WHEEL_SPEED, Math.min(simulation.leftWheelSpeed, simulation.MAX_LEFT_WHEEL_SPEED));
                simulation.rightWheelSpeed = Math.max(-simulation.MAX_RIGHT_WHEEL_SPEED, Math.min(simulation.rightWheelSpeed, simulation.MAX_RIGHT_WHEEL_SPEED));

                // Apply friction to slow down the wheels
                if (simulation.leftWheelSpeed > 0) {
                    simulation.leftWheelSpeed -= simulation.FRICTION;
                    if (simulation.leftWheelSpeed < 0) {
                        simulation.leftWheelSpeed = 0;
                    }
                } else if (simulation.leftWheelSpeed < 0) {
                    simulation.leftWheelSpeed += simulation.FRICTION;
                    if (simulation.leftWheelSpeed > 0) {
                        simulation.leftWheelSpeed = 0;
                    }
                }

                if (simulation.rightWheelSpeed > 0) {
                    simulation.rightWheelSpeed -= simulation.FRICTION;
                    if (simulation.rightWheelSpeed < 0) {
                        simulation.rightWheelSpeed = 0;
                    }
                } else if (simulation.rightWheelSpeed < 0) {
                    simulation.rightWheelSpeed += simulation.FRICTION;
                    if (simulation.rightWheelSpeed > 0) {
                        simulation.rightWheelSpeed = 0;
                    }
                }

                simulation.update();
                delta--;
            }

            // Sleep to control frame rate
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    
    
    public void startListening(int port) {
    		try {
                serverSocket = new ServerSocket(port);
                System.out.println("Server started, waiting for client to connect...");

                clientSocket = serverSocket.accept();
                System.out.println("Client connected");

                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                startListenerThread();
            } catch (IOException e) {
                System.err.println("I/O error when setting up server");
                e.printStackTrace();
            }
    }

    private void startListenerThread() {
        listenerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (running) {
                    try {
                        String message = in.readLine();
                        if (message != null) {
                            String[] values = message.split(" ");
                            String btnName = values[0];
                            float btnValue = Float.parseFloat(values[1]);
                            switch (btnName) {
                                case LSTICKXAXIS:
                                    lstickXValue = btnValue;
                                    if (btnValue > 0) {
                                        destraPressed = true;
                                        sinistraPressed = false;
                                    } else if (btnValue < 0) {
                                        sinistraPressed = true;
                                        destraPressed = false;
                                    } else {
                                        destraPressed = false;
                                        sinistraPressed = false;
                                    }
                                    break;
                                case RSTICKYAXIS:
                                    rstickYValue = btnValue;
                                    if (btnValue > 0) {
                                        giuPressed = true;
                                        suPressed = false;
                                    } else if (btnValue < 0) {
                                        suPressed = true;
                                        giuPressed = false;
                                    } else {
                                        giuPressed = false;
                                        suPressed = false;
                                    }
                                    break;
                                case R2:
                                    r2Value = btnValue;
                                    avantiPressed = btnValue > 0;
                                    break;
                                case L2:
                                    l2Value = btnValue;
                                    indietroPressed = btnValue > 0;
                                    break;
                                case O:
                                    continue;
                                case SQUARE:
                                    continue;
                                default:
                                    continue;
                            }
                        }
                    } catch (IOException e) {
                        if (running) {
                            System.err.println("Error reading incoming message");
                            e.printStackTrace();
                            stopConnection();
                        }
                    }
                }
            }
        });
        listenerThread.start();
    }

    public String sendMessage(String msg) {
        if (clientSocket != null && clientSocket.isConnected()) {
            out.println(msg);
        } else {
            System.err.println("No client connected. Unable to send message.");
        }
        return msg;
    }

    public void stopConnection() {
        running = false;
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (clientSocket != null && !clientSocket.isClosed()) clientSocket.close();
            if (serverSocket != null && !serverSocket.isClosed()) serverSocket.close();
            System.out.println("Connection closed successfully");
        } catch (IOException e) {
            System.err.println("Error while closing connection");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("EV3 Simulation");
        frame.add(simulation);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        int portaAscolto = 6969;
        Server server = new Server();
        server.startListening(portaAscolto);
        server.updateLoop();
        
        
    }
}
